---
name: vjtb-host-setup
description: Finish TouchDesigner, Resolume Wire/Arena and OSC-bridge setup for VJTB Stinger Studio using only vendor-verified API facts, with optional TDMCP / Resolume MCP servers, and rehearse without hosts via mock_hosts.mjs. Also covers what to send when: Push to Live Host for a new or changed shader, "Send preset" (parameters only) for a preset change on an effect that is already in the host. Use for any host connection, port, OSC mapping, show-machine or "why is the host not moving" question.
---

# VJTB host setup

## Verified facts. Do not contradict them (sources in REALITY-CHECK.md)
- **Resolume Arena**
  - REST and WebSocket run at `/api/v1` on port 8080 (Preferences → Webserver). There is **no Arena v2**.
  - Set a parameter with `{"action":"set","parameter":"/parameter/by-id/<id>","value":<native units>}`.
  - The full composition JSON is pushed on connect. Effects live at `layers[].video.effects[]` with a `params` map of `{id, valuetype, min, max}`.
  - OSC input is on port 7000 and takes 0..1 floats. `/composition/layers/N/dashboard/link1..8` is the documented, effect-agnostic target.
- **Resolume Wire**
  - The REST API is `/api/v2` on port 8081.
  - ISF runs through the ISF node. Arena does not load `.fs` files directly.
  - A patch with Category = Effect, saved to `Documents/Resolume Wire/Patches/`, appears in Arena.
  - Resolume documents float/bool/color/event inputs for ISF nodes, so use the Wire-safe export.
- **TouchDesigner**
  - Does not load ISF; use the GLSL TOP translation.
  - GLSL TOP parameters are `pixeldat`, `outputresolution='custom'`, `resolutionw/h`, and `format='rgba32float'`.
  - Vector uniforms use the `vec` sequence: `vec0name`, `vec0valuex..w`, `seq.vec.numBlocks`.
  - There is no time uniform, so bind `absTime.seconds`.
  - Web Server DAT callbacks take `(dat, ...)`; send with `dat.webSocketSendText`.
- **MCP servers**
  - Official TDMCP: `http://127.0.0.1:13316/mcp`.
  - Community `Pantani/tdmcp`: port **9980**, which collides with the default Web Server DAT port.
  - Resolume ships Wire and Arena MCP servers from 7.26.

## Procedure
1. **Rehearse first, without hosts.** With `npm run dev` running, run `python3 scripts/e2e_sync.py`. It starts `scripts/mock_hosts.mjs` itself (fake TD on 9980, fake Arena on 8080, OSC listeners on UDP 7000 and 10000), so do not start the mock separately: the ports would clash and the log would be empty. All checks must pass before you touch the real hosts. Then `python3 scripts/test_td_bridge.py` checks the TD callbacks against a stub of the TD API. To click through the app by hand against fakes, run `node scripts/mock_hosts.mjs` alone, and stop it before real hosts start because it holds their ports.
2. **TouchDesigner**
   - Create a Web Server DAT (port 9980, Active = On) and set its Callbacks DAT to the text of `td/vjtb_webserver_callbacks.py`.
   - Press Push in the app and verify `/project1/vjtb/pass0` has no errors.
   - The stub test `python3 scripts/test_td_bridge.py` documents the expected network.
3. **Resolume**
   - Build the Wire patch from the Wire-safe `.fs`.
   - Enable the webserver and OSC, put the effect on the logo layer, and map dashboard links.
   - Pick the effect in the app's Sync tab.
4. **Bridge (show mode):** run `node bridge/server.mjs --port 9010 --resolume-dir ... --td-dir ...`. Check it with `node scripts/osc-monitor.mjs 7001`.
5. Report what you created, what you verified, and anything that contradicted these facts. If something did contradict them, update REALITY-CHECK.md with the source.

## What to send, and when
| You changed | Use | What it does |
|---|---|---|
| Effect, shader code, or render resolution | **Push to Live Host** | Sends the logo, the translated shader and every parameter. TD destroys and rebuilds `pass*`, `shader_*`, `fb_*` and `out1`; the bridge rewrites the `.fs` and `.frag` files in the host's shader folders. |
| A preset, or sliders, of an effect already in the host | **Send preset** (parameters only) | Sends every parameter of the current effect as TD `params`, OSC and Resolume set-by-id. No network rebuild, no file writes, no logo. |
| One slider | nothing | Live streaming (`tick`) already sends it. |

Why the split: a push interrupts the output (a rebuild hitches and can reset host-side state) and rewrites files the host may be watching, which you do not want mid-show. Switching a look between two presets of the same shader needs none of it. So push once when the shader is final, and use Send preset for everything after.
- Send preset only works if the effect is already in the host: the TD network exists from an earlier push, or Resolume has the effect on the layer and the Sync tab target matches it. If not, the app should say so; push first.
- Parameter names, labels and ranges are the contract with the host. After renaming or re-ranging a parameter, push again and re-map dashboard links, because Resolume matches by label and TD by uniform name.
- Audio bands are not streamed unless "Stream audio bands" is on; the host should drive `uBass`, `uMid`, `uHigh` and `uBeat` from its own analysis and BPM clock.
