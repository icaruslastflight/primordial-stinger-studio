---
name: vfx-effect-research
description: Lightweight, time-boxed research run across VFX / shader / VJ / motion-design information sites to gather concrete, implementable effect concepts (with technique notes and source links) for logo reveals, DJ and club visuals, and broadcast stingers. Use it before designing new shader effects, when someone asks for fresh effect ideas or trends, or when a library of looks needs expanding. Runs on cheap models (Sonnet or Haiku). Do not use Opus for web search.
---

# VFX effect research (lightweight)

**Goal:** turn about 15 minutes of targeted browsing into 8–12 *implementable* effect concepts. Each concept must be buildable as a single-pass, GLSL ES 1.00 ISF fragment shader that takes a logo as its only image input.

You are feeding a shader designer, not writing an essay. Prefer *how it's done* over *what's trending*.

## Budget and model
- **Budget:** at most 12 searches and 10 page fetches per run. Stop early once you have enough strong concepts.
- **Model:** run on Sonnet or Haiku. If you are an orchestrator, spawn the researchers with `model: sonnet` or `haiku`. The user does not want Opus for web search.

## Where to look (pick the ones that fit your angle)
| Angle | Sources |
|---|---|
| Shader technique | shadertoy.com (search + tags), iquilezles.org/articles, thebookofshaders.com, isf.video and the vidvox/ISF-FILES library, github "ISF shaders", ronja-tutorials, Inigo Quilez SDF / noise articles |
| VJ, DJ, club | resolume.com blog and forum, derivative.ca community and forum, VJ Union (vjun.io), vjloops sites (Beeple / VJ loop packs), Notch blog, TouchDesigner tutorials (Bileam Tschepe / elekktronaut, Matthew Ragan), reddit r/vjing |
| Brand and broadcast motion | School of Motion, Motionographer, Behance / Dribbble "logo reveal" and "broadcast package", Envato / Motion Array logo-reveal categories (titles and descriptions only, for trend names) |

## Query recipes
- `"<look> shader" site:shadertoy.com`, e.g. "kaleidoscope logo", "liquid chrome", "laser scan", "halftone dissolve"
- `site:iquilezles.org <technique>`: domain warping, palettes, SDF smooth union, voronoise
- `"logo reveal" trends <year>` and `"VJ loop" <genre>` (techno, hardstyle, dubstep, psytrance, house)
- `site:resolume.com/blog <feature>` or `site:derivative.ca <technique> logo`

## What a concept card must contain
```markdown
### <Effect name>   [category: flora|fluid|metal|glitch|sting] [audience: brand|dj|both]
Look: one or two sentences a VJ would recognise.
Technique: the core math, e.g. "polar kaleidoscope fold of logo UVs, N segments, rotating by bass".
Single-pass feasible: yes/no plus why. No persistent buffers; ≤ ~60 texture taps per pixel.
Controls: map onto the category's existing params (list them) and add at most 2 extras.
Audio hook: what the kick / bass / highs drive. It must be structural, not only brightness.
Brand safety: is the logo legible at rest? If it's a DJ look, say so.
Sources: 1–3 URLs you actually opened.
```

## Quality bar
- **Concrete over generic.** "Spectral audio rings ripple outward from the logo outline using the distance field" beats "cool audio effect".
- **Discard anything that needs** multiple passes, 3D meshes, external textures, or video input.
- **Balance the audience.** For DJ logos think festival LED walls: strobes, lasers, bass hits, kaleidoscopes, acid, tunnels, hardstyle red/black. For corporate logos think legibility, premium materials, restrained motion and hero lockups.
- **Cite only pages you opened.** If a fact is unverified, say so.

## Output
Return the concept cards, then a one-paragraph summary: the best 3 picks and any technique worth adding to the shared GLSL library.
