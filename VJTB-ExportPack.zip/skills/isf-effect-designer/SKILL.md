---
name: isf-effect-designer
description: Design, build and critically QA new dynamic logo effects (logo reveals, DJ/club visuals, broadcast stingers) as single-pass ISF 2.0 / GLSL ES 1.00 shaders for VJTB Stinger Studio, exportable to Resolume Wire and TouchDesigner. Use it whenever someone wants new effects, more effects, effect variations, effects for a DJ or corporate logo, or an upgrade to an existing effect, even if they never say "ISF" or "shader".
---

# ISF effect designer

You turn a concept brief into a production effect that previews in the app and exports unchanged to ISF 2.0, Wire-safe ISF and TouchDesigner. It must also survive a harsh visual review. Most failures in this project came from shipping something that compiled but looked bad, or had controls that did nothing. So the loop below ends with *looking*, not with compiling.

Read these first. They are short and every rule cites the defect it prevents:
- `docs/EFFECT-RULES.md`, the binding rules.
- `src/isf/glslLib.ts`, the helpers you should use instead of re-inventing them.

## 1. Pick the audience mode before writing a line
| Mode | For | Must | Avoid |
|---|---|---|---|
| **brand** | sponsor and corporate logos | Exact legibility at rest. Premium materials (metal, glass, ink, light). Restrained, eased motion. Colours from `uTint` or the palette. | Melting or eroding letterforms at rest, hard-coded hues, gratuitous noise. |
| **dj** | DJ, club and festival logos on LED walls | Impact. Audio must be **structural**: the kick drives scale, displacement, cuts or segment count, not only brightness. High contrast. Genre palettes (techno cold mono, hardstyle red and black, psytrance UV/acid, house warm). Beat lock via `BEAT_PARAM` (`uBeat`, a 0→1 sawtooth per beat). | Full-frame white flashes faster than about 3 per second at default settings (photosensitivity). An unreadable logo on *every* frame: the mark must land on the beat or the hold. |
| **both** | either | A restrained default preset plus an aggressive preset. | |

Set `audience:` on the EffectDef.

## 2. Map onto the category's fixed controls
Every category has a fixed control set, which the spec requires. Reuse it, and add at most 2 extras (`uBeat` counts as one). If a category control has no physical meaning in your effect, *reinterpret it* and put that meaning in the param `hint`. For example, Mercury's "Collision Bounce" became surface-tension ripple. Never leave a control dead: QA will flag it.

The category sets are exported from:

| Category | Constant | File |
|---|---|---|
| flora | `FLORA` | `botanical.ts` |
| fluid | `FLUID(tint)` | `particle.ts` |
| metal | `METAL(tint)` | `volumetric.ts` |
| glitch | `GLITCH` | `glitch.ts` |
| sting | `STING` + `STING_MAIN` | `stingers.ts` |

All of them also take `UNIVERSAL_PARAMS` from `common.ts`. Stingers implement `vec4 stingerFrame(vec2 p, float t)`, which returns premultiplied RGBA, and append `${STING_MAIN}`. That main loop handles the shutter blur (6 taps, so your per-frame cost is multiplied by 6), the shake, and idle transparency.

## 3. Write the GLSL (single pass, GLSL ES 1.00)
- Start from the category `HEAD` preamble: `uv`, aspect-corrected `p`, `t`, `aud`.
- **Logo access:**
  - `logoP(p)` gives alpha.
  - `logoRGBA(p)` gives colour and alpha.
  - `logoField(p, r)` gives coverage and the inward gradient (25 taps).
  - `fieldSD(F, r)` gives an approximate signed distance.
  - `edgeGlow(sd, k, r)` gives a glow that falls to exactly zero.
  - `logoCov5(p, r)` is a cheap outline test.
- **Toolbox:**
  - Noise: `vnoise`, `fbm`, `fbm3`, `warp2(p, q, r)`.
  - Colour: `palCos`, `blackbody`.
  - Geometry: `curl2`, `rot2`, `foldPolar(p, n, rot)`, `bayer8(cell)`.
  - Materials and motion: `studioEnv` (chrome), `spores`, `leafSD`, `ease*`.
  - Clocks: `stingerClock`, `hitEnv`, `shakeOffset`, `glitchClock`, `glitchBurst`.
- **Hard rules, each with the reason it exists:**
  - **Constant loop bounds**: GLSL ES 1.00. Use `if (...) break;`.
  - **Float literals**: there is no implicit int→float conversion.
  - **Input conversion**: `int(float(uX)+0.5)` for long inputs and `bool(uX)` for bool inputs, because the same body compiles as int, float or TD `#define`.
  - **No comma inside `IMG_*PIXEL(...)` arguments**: the ISF-JS reference parser splits on commas. Use `imgClamp(uv)` or a local variable.
  - **Write only through `vjOut(col, solid)` / `vjOutPM(rgba)`**: straight alpha for ISF, premultiplied for TD.
  - **Keep it under about 60 texture taps per pixel** (stingers: per `stingerFrame`, ×6).
- Put effect-local helper functions inside your effect's `glsl` string, above `main`. Name them with a unique prefix to avoid collisions with the library.

## 4. Presets
Ship three presets: a hero look and two clearly different variants, such as a palette, genre or intensity change. For **both**-audience effects, one preset must be brand-calm and one DJ-aggressive. Give progress-like params an `auto` LFO so the deck shows motion.

## 5. Verify, then look, then critique (required)
Use your own dev server port if you work in a worktree:
```bash
npx tsc -p tsconfig.app.json --noEmit
python3 scripts/visual_check.py --compile-only --only <ids> --url http://localhost:<port>/verify.html
python3 scripts/qa_effects.py --only <ids> --tag <run> --url http://localhost:<port>/verify.html
python3 scripts/visual_check.py --gif --only <ids> --out verify-out/gif --url http://localhost:<port>/verify.html
```
- The compile check covers WebGL2, GLSL ES 1.00, the TD translation and Wire-safe.
- `qa_effects.py` reports DEAD/WEAK controls, flicker, audio and alpha stats.
- `--logo auto` picks the DJ sample logo (NOVA) for `dj` effects and the corporate one otherwise. Check `both` effects with both logos (`--logo dj`).
- After the scripts, **open `verify-out/gif/<id>-gifsheet.png` and `verify-out/qa/<run>/<id>-controls.png` with your image viewer at full size.** Never skip this step.
- Critique honestly using the vjtb-visual-qa template:
  - legible at rest
  - silhouette intact
  - nothing drawn outside the effect
  - motion arc
  - detail scale
  - colour
  - controls
  - structural audio
  - flicker
  - for dj: impact and strobe safety
- Fix and re-render. Two rounds is the minimum.
- Write the critique (issues → changes → numbers before → after) into your QA notes file.

## 6. Scaling up: N effects in parallel (orchestrators)
- **Designers:** one designer sub-agent per category.
  - Each gets its own `git worktree` with `node_modules` symlinked and its own vite port (518x).
  - Each edits only `src/effects/ext/<category>.ts` (and its base category file if fixing existing effects).
  - Designers run on Opus with high effort.
- **Reviewers:** an independent reviewer agent per category (Sonnet, high effort, never the author) critiques the GIF and control sheets. The author then fixes, and the orchestrator merges the branches.
- **Research beforehand:** use the vfx-effect-research skill on Sonnet or Haiku, never Opus for web search.

See `references/techniques.md` for snippets: kaleidoscope fold, halftone/Bayer, contour bands, spectrum rings, anisotropic sweep, stateless particles, strobe gating, beat phase.
