# Technique cookbook (GLSL ES 1.00, ISF single pass)

Compact building blocks for logo effects. Copy the functions into your effect's `glsl` string above `main()`. Library helpers (`logoP`, `rot2`, `foldPolar`, `bayer8`, `hash*`, `curl2`...) are tree-shaken in automatically, so do not paste those.

How it was checked (2026-10-16): every fenced snippet was wrapped in a minimal ISF file and passed `node scripts/isf-lint.mjs`. Every function block, concatenated into one ISF body, compiled on all four targets (WebGL2, GLSL ES 1.00, TouchDesigner, Wire-safe) and passed the official ISF-JS renderer. The snippets for §1, §3, §6, §12 and §14 were also rendered with both sample logos and `strobeGate` was measured with `strobe_check.py`. That proves the snippets compile and behave, not that your effect looks good: still run the full QA loop.

Conventions used below (they match every category `HEAD`):
- `p = uv2p(isf_FragNormCoord)`: centred, height-normalised. `p.y` runs from −0.5 to 0.5 and `p.x` from ±0.89 at 16:9. 1 px = `1.0 / RENDERSIZE.y`.
- `logoP(p)` is logo alpha and `logoRGBA(p)` is colour plus alpha (luma-key aware). Both return 0 outside the plate.
- `kick = uBass * uAudioReact` (0..2). `uMid` and `uHigh` are the other two bands. Built-ins have no FFT texture, because Wire documents only float, bool, color and event inputs.
- Cost is counted in texture taps per pixel: `logoP` = 1, `logoCov5` = 5, `logoField` = 25.

## Contents
1. Beat phase, kick map, strobe gate
2. Rest-state composite (legibility)
3. Kaleidoscope fold and segment crossfade
4. Halftone and Bayer dither
5. Smooth logo distance (near and far)
6. Contour lines and iso-bands
7. Spectrum rings
8. Light sweep and anisotropic highlight
9. Chromatic dispersion
10. Stateless shed grains (back-traced cohorts)
11. Log-polar scrolling-grid sparks
12. Truchet tiling
13. Moiré reveal
14. Vogel-disc blur (focus pull, halo)

---

## 1. Beat phase, kick map, strobe gate
`uBeat` is the beat clock. It is `BEAT_PARAM` in `src/effects/common.ts` (driver `beat`): a 0→1 sawtooth per beat from the app's BPM clock, the same clock that makes the synthetic 124 BPM kick, so `uBeat = 0` is the kick onset in the app and in the verifier. It costs one of your two extras (`params: [...CAT, BEAT_PARAM, ...UNIVERSAL_PARAMS]`). In a host, map it to a BPM-synced parameter (Resolume) or a beat ramp (TouchDesigner).

Do not build the beat from `TIME * bpm / 60`. `TIME` restarts with the app's clock (RESTART, preset change) and host clocks are not phase-aligned with the music, so a TIME grid only lines up with the kick inside the verifier. Use `TIME` for things that need no downbeat alignment: slow drift, seeds, idle motion.

Use `uBeat` for *cadence* (what changes within a beat) and `uBass` for *impact* (how hard the kick hits). Phase alone has no beat counter, so "different every beat" is not available: sub-beat indices such as `floor(uBeat * 4.0)` repeat each beat, and a slow `floor(TIME * 0.25)` seed can make the pattern evolve.

Where a tempo in real units is needed (the strobe cap below, scroll speed per beat):
- **glitch:** reinterpret `uGlitchFreq` as the beat length (`bpm = 60.0 / uGlitchFreq`, so 0.484 s at 124 BPM). Say so in `hint`.
- **sting:** set `uDuration` to N beats (`60·N/BPM`) and put `uHitPoint` on a beat fraction.
- **Every other category:** spend the second extra on `fl('uBpm', 'Tempo', 124, 60, 200, { unit: 'BPM' })`.
- Or avoid needing it: express speeds as "per beat" and multiply by `uBeat`.

```glsl
// Envelope that peaks on the downbeat and decays. k ≈ 6 matches the synthetic kick (exp(-6·phase)).
float beatPulse(float ph, float k) { return exp(-ph * k); }
// Safe strobe from beat phase ph (= uBeat). perBeat = flashes per beat, duty = lit fraction of each slot.
// The count is clamped so the rate cannot exceed 3 flashes/s at tempo `bpm` (WCAG 2.3.1, Ofcom).
// One flash per beat is the slowest a phase-locked gate can go, so above 180 BPM it passes 3/s: gate
// every second beat from a TIME counter there (safe, not downbeat-locked) or drop the full-frame flash.
float strobeGate(float ph, float bpm, float perBeat, float duty) {
  float cap = max(floor(180.0 / max(bpm, 1.0)), 1.0);
  float n = clamp(floor(perBeat + 0.5), 1.0, cap);
  float f = fract(ph * n);
  return step(f, duty) * exp(-f * 8.0);
}
```
Kick map. Make the kick move *structure*, not only brightness (EFFECT-RULES 4.3):
```
p /= 1.0 + 0.08 * kick;                                   // scale punch toward the viewer
p += normalize(p + 0.0001) * 0.012 * kick;                // radial shove
float sl = floor(isf_FragNormCoord.y * 12.0);             // slice tear: four patterns per beat, repeated each beat
p.x += (hash11(sl + floor(uBeat * 4.0) * 17.0) - 0.5) * 0.04 * kick;
```
Strobe safety:
- `strobeGate` clamps itself to 3 flashes/s. `strobe_check.py` measured an 8th-note gate at 124 BPM as 3 flashes in a 1 s window with the clamp and 5 without it.
- A kick-driven lift of the whole frame is safe at any rate only if it stays under about 0.07 relative luminance, which is sRGB grey 0.3.
- A full-logo white flash counts as a flash, because the logo fills more than 25% of its local field.

## 2. Rest-state composite (legibility)
Every brand effect, and every DJ effect on the beat, must show the untouched logo at rest (EFFECT-RULES 2.1). Build the wild layer first, then composite the true logo over it, weighted by a `rest` term:
```
float rest = 1.0 - smoothstep(0.0, 0.3, uBeat);                  // DJ: clean logo on each downbeat
// brand: rest = growth/progress at 100%, or the stinger hold window
vec4 lg = logoRGBA(p);
vec3 col = mix(fxCol, lg.rgb, lg.a * rest);
float alpha = max(fxAlpha, lg.a * rest);
```

## 3. Kaleidoscope fold and segment crossfade
**Use:** DJ (psytrance, techno), as a mandala behind or around the logo. **Cost:** 2 taps.

The library has `foldPolar(p, n, rot)`: it mirror-folds `p` into one wedge of an n-segment kaleidoscope. Mirroring keeps the seams continuous, but only for whole `n`; a fractional `n` leaves a seam at the ±180° atan wrap and pops when it crosses an integer. To let the kick *grow* the segment count, fold at `floor(n)` and `floor(n) + 1` and blend the two samples:
```glsl
// Segment-count crossfade. Each fold is seamless; blending them glides n (e.g. 4 + 6·kick) with no pop.
// zoom scales the folded coordinate and off shifts it, so the wedges slice through the letterforms
// (with off = 0 every wedge samples the logo's empty centre). Returns PREMULTIPLIED rgba: feed vjOutPM.
vec4 kaleidoMix(vec2 p, float n, float spin, float zoom, vec2 off) {
  float n0 = floor(n);
  float w = smoothstep(0.0, 1.0, n - n0);
  vec4 a = logoRGBA(foldPolar(p, n0, spin) * zoom + off);
  vec4 b = logoRGBA(foldPolar(p, n0 + 1.0, spin) * zoom + off);
  return mix(vec4(a.rgb * a.a, a.a), vec4(b.rgb * b.a, b.a), w);
}
```
Usage:
```
float n = 4.0 + 6.0 * clamp(kick, 0.0, 1.0);                         // more segments on the hit
vec4 k = kaleidoMix(p / (1.0 + 0.12 * kick), n, TIME * 0.15, 1.4, vec2(0.3, 0.0));
k *= 1.0 - smoothstep(0.42, 0.48, length(p));                         // disc mask: never touches the frame edge
```
Then apply §2. Folding destroys legibility, so it is never the rest state.

## 4. Halftone and Bayer dither
**Use:** both. Halftone gives print or pop-art; ordered dither gives retro and LED-wall pixel looks. **Cost:** 5 taps.
```glsl
// 2x2 → 4x4 ordered (Bayer) dither threshold in 0..1, from pixel coords. No arrays needed.
float bayer2(vec2 a) { a = mod(floor(a), 2.0); return fract(dot(a, vec2(0.5, a.y * 0.75))); }
float bayer4(vec2 a) { return bayer2(0.5 * a) * 0.25 + bayer2(a); }
// Rotated AM halftone of the logo: dot AREA follows local coverage, sampled at the cell centre
// so dots stay round. cell = pitch in height units (0.012 ≈ 9 px at 720p).
float halftoneLogo(vec2 p, float cell, float ang) {
  vec2 q = rot2(ang) * p / cell;
  vec2 c = rot2(-ang) * ((floor(q) + 0.5) * cell);
  float tone = logoCov5(c, cell * 0.35);
  float r = sqrt(tone) * 0.62;
  float aa = 1.5 / (RENDERSIZE.y * cell);
  float dotm = 1.0 - smoothstep(r - aa, r + aa, length(fract(q) - 0.5));
  return dotm * smoothstep(0.02, 0.08, tone);   // zero tone → no dot (else a faint dot in every cell = full-frame dirt)
}
```
Notes:
- The library also has `bayer8(cell)` (8×8, closed form); the 4×4 above is the coarser look. Both take integer cell coordinates.
- Dither with a strict compare: `float on = v > bayer4(gl_FragCoord.xy / 2.0) ? 1.0 : 0.0;`. Writing `step(bayer, v)` lights every pixel where both are 0, which puts a dot grid over the whole frame. That shipped in the first draft of this snippet.
- Bigger cells on the kick (`cell * (1.0 + 0.6 * kick)`) give a punchy DJ variant.
- There is no `fwidth` in GLSL ES 1.00, so derive anti-aliasing widths from `RENDERSIZE` as shown.

## 5. Smooth logo distance (near and far)
`fieldSD(logoField(p, R), R)` is cheap, but it is quantised to 1/25 coverage steps. Iso-lines drawn from it come out as ghosted copies of the outline (seen in testing). Two smooth alternatives:
```glsl
// Smooth signed distance to the logo edge (+ outside, − inside, clamped to ±R).
// logoField alone is quantised to 1/25 coverage steps (25 taps), which turns iso-lines into
// ghosted copies of the outline; bisecting along the field normal for the 0.5-alpha crossing
// (6 extra taps) makes it smooth to ~R/64.
float logoSD(vec2 p, float R) {
  vec3 F = logoField(p, R);
  float sd0 = fieldSD(F, R);
  if (abs(sd0) > R * 0.96) return sd0;
  vec2 n = length(F.yz) > 0.0001 ? normalize(F.yz) : vec2(0.0, 1.0);
  bool inside = logoP(p) > 0.5;
  vec2 dir = inside ? -n : n;
  float lo = 0.0; float hi = R;
  for (int i = 0; i < 6; i++) {
    float mid = 0.5 * (lo + hi);
    bool crossed = (logoP(p + dir * mid) > 0.5) != inside;
    if (crossed) hi = mid; else lo = mid;
  }
  float d = 0.5 * (lo + hi);
  return inside ? -d : d;
}
// Far-field outside distance (0 on/inside the ink, capped at R): min over 8 rays of the first ink
// crossing, found by an 8-step march then a 4-step bisection. 96 taps. Rings stay ~8% octagonal
// (ray spacing 45°) and strokes thinner than R/8 can be skipped by the march.
float logoDistFar(vec2 p, float R) {
  if (logoP(p) > 0.5) return 0.0;
  float best = R;
  for (int k = 0; k < 8; k++) {
    float a = float(k) * 0.7853982;
    vec2 dir = vec2(cos(a), sin(a));
    float lo = 0.0; float hi = -1.0;
    for (int i = 1; i <= 8; i++) {
      float s = R * float(i) / 8.0;
      if (hi < 0.0) { if (logoP(p + dir * s) > 0.5) hi = s; else lo = s; }
    }
    if (hi < 0.0) continue;
    for (int j = 0; j < 4; j++) {
      float mid = 0.5 * (lo + hi);
      if (logoP(p + dir * mid) > 0.5) hi = mid; else lo = mid;
    }
    best = min(best, 0.5 * (lo + hi));
  }
  return best;
}
```
- `logoSD` costs 32 taps. It gives clean, unbroken rings out to R ≈ 0.05. The bisection follows the average inward direction of the field, which points at the nearest *edge* only close to the ink; further out, between letters, the rings turn ragged (visible at R = 0.12 and broken at R = 0.2).
- For halos wider than about 0.06 use `logoDistFar`: smooth, but slightly octagonal and 96 taps.

## 6. Contour lines and iso-bands
**Use:** both. A topographic halo works for brand; for DJ, scroll the bands on the beat. Both come from `logoSD` (§5, built on `logoField`). Do not use the raw `fieldSD`: its 1/25 steps show up as ghost outlines.
```
float R = 0.05; float sd = logoSD(p, R);
float fade = step(0.0, sd) * (1.0 - smoothstep(R * 0.5, R * 0.95, sd));   // exactly 0 before R → no frame floor
// contour lines, one every 0.01 (about 7 px at 720p), drifting outward
float k = abs(fract(sd / 0.01 - TIME * 0.25) - 0.5) * 0.01;            // distance to nearest iso-line
float line = (1.0 - smoothstep(0.0012, 0.0012 + 1.0 / RENDERSIZE.y, k)) * fade;
// iso-bands: alternate filled rings, stepped outward once per beat by uBeat
float bw = 0.01;
float tri = abs(fract(sd / (2.0 * bw) - uBeat) - 0.5) * 2.0;           // triangle wave, one period = 2 bands
float aa = 1.0 / (bw * RENDERSIZE.y);                                  // one pixel in tri units
float band = smoothstep(0.5 - aa, 0.5 + aa, tri) * fade;
col += uTint.rgb * (0.7 * band + 0.5 * line);                          // use either term, or both
```
`R = 0.05` gives clean rings (see §5 for why wider is ragged). For a wide halo (R up to 0.12) swap in `logoDistFar(p, R)` for `logoSD(p, R)`: it is smoother but slightly octagonal, and costs 96 taps.

## 7. Spectrum rings
**Use:** DJ. Rings travel outward from the outline; the inner ones ride the bass and the outer ones the highs. A stateless shader cannot remember past audio, so every ring reacts to the *current* level.
```glsl
// 3-band "spectrum" lookup: built-ins only receive uBass / uMid / uHigh (no FFT texture in Wire).
float bandAt(float x) { return x < 0.5 ? mix(uBass, uMid, x * 2.0) : mix(uMid, uHigh, x * 2.0 - 1.0); }
// Rings travel outward from the outline; inner rings ride the bass, outer rings the highs.
// sd from logoSD (smooth) or fieldSD (cheap, steppy). Falls to exactly 0 at R → no frame floor.
vec3 spectrumRings(float sd, float R, float t, vec3 cLo, vec3 cHi) {
  if (sd <= 0.0 || sd >= R) return vec3(0.0);
  float x = sd / R;
  float lvl = clamp(bandAt(x) * uAudioReact, 0.0, 1.5);
  float rings = 5.0;
  float d = abs(fract(x * rings - t * 0.7) - 0.5);
  float w = 0.06 + 0.22 * lvl;
  float aa = 1.5 * rings / (R * RENDERSIZE.y);
  float ring = 1.0 - smoothstep(w * 0.5, w * 0.5 + aa, d);
  float fade = (1.0 - x) * (1.0 - x);
  return mix(cLo, cHi, x) * ring * fade * (0.6 + 1.6 * lvl);
}
```
Pass `logoSD(p, 0.12)` for tight rings, or `logoDistFar(p, 0.25)` with `R = 0.25` for a wide halo.

## 8. Light sweep and anisotropic highlight
**Use:** brand (the premium sheen). Mask everything to the ink.
```glsl
// Diagonal light sweep: a soft band crosses the frame once per period (eased), mask it to the ink.
float lightSweep(vec2 p, float t, float period, float width, vec2 dir) {
  float pos = mix(-1.3, 1.3, easeInOutCubic(fract(t / period)));
  float d = dot(p, normalize(dir)) - pos;
  return exp(-d * d / (width * width));
}
// Kajiya-Kay anisotropic highlight: streaks run along tangent T (brushed / spun metal).
float aniso(vec3 T, vec3 L, vec3 V, float expo) {
  vec3 H = normalize(L + V);
  float th = dot(T, H);
  return pow(sqrt(max(1.0 - th * th, 0.0)), expo);
}
```
Bevel normal from the field, plus spun-metal tangent:
```
vec3 F = logoField(p, 0.02);  vec2 g = length(F.yz) > 0.0001 ? normalize(F.yz) : vec2(0.0);
vec3 N = normalize(vec3(-g * 4.0 * F.x * (1.0 - F.x) * 1.5, 1.0));
vec3 T = normalize(vec3(-p.y, p.x, 0.0001)); T = normalize(T - N * dot(T, N));   // circular brushing
vec3 L = normalize(vec3(cos(TIME * 0.6), sin(TIME * 0.6), 0.8));
col = (logo.rgb * (0.55 + 0.45 * N.z) + uTint.rgb * aniso(T, L, vec3(0.0, 0.0, 1.0), 40.0) * 0.6
       + lightSweep(p, TIME, 3.0, 0.08, vec2(1.0, 0.6)) * 0.8) * logo.a;
```
For glossy chrome, use the library's `studioEnv(reflect(...), rough, spin)` instead (see `metal-chrome`).

## 9. Chromatic dispersion
**Use:** both. Hold `amt` near 0 for brand at rest; for DJ, let the kick drive `amt`. **Cost:** 7 taps.
```glsl
// Spectral dispersion: 7 taps along dir, each weighted into R/G/B by its "wavelength".
// Per-channel normalisation means amt = 0 returns the untouched logo (brand-safe at rest).
vec4 disperse(vec2 p, vec2 dir, float amt) {
  vec3 acc = vec3(0.0); vec3 wsum = vec3(0.0); float a = 0.0;
  for (int i = 0; i < 7; i++) {
    float k = float(i) / 6.0;
    vec3 w = clamp(vec3(1.0 - abs(k - 0.1) * 2.6, 1.0 - abs(k - 0.5) * 2.6, 1.0 - abs(k - 0.9) * 2.6), 0.0, 1.0);
    vec4 s = logoRGBA(p + dir * (k - 0.5) * amt);
    acc += s.rgb * s.a * w; wsum += w; a = max(a, s.a);
  }
  return vec4(acc / wsum, a);
}
```
- Radial: `disperse(p, normalize(p + vec2(0.0001, 0.0)), 0.01 + 0.05 * kick)`.
- Directional: a fixed `dir`, re-rolled per glitch burst.

## 10. Stateless shed grains (back-traced cohorts)
**Use:** dust, ash, glitter or pixels peeling off the ink. A stateless shader cannot move particles forward, so each pixel asks "which grain born on the logo would be here now?".
- Layer k is a cohort that re-spawns every `life` seconds, staggered by `life/8`.
- Back-trace by solving `h = p − drift(h, age)` as a fixed point. Drift depends on the birth point, so two iterations are needed; with one, grains wobble.
- The grain shape lives in *birth* space, so it stays stable while the grain travels.
- **Cost:** about 8 × (2 × `curl2` + 1) taps. It renders at ~1 s/frame in SwiftShader, so test it with `--only`.
```glsl
// Stateless shed grains (cohort layers). Layer k is a cohort that re-spawns every `life` s, staggered
// by life/8, so every grain in a layer shares one age. Back-trace: solve h = p - drift(h, age) by
// fixed-point iteration (drift depends on the birth point), then test for a grain born at h.
// Grains live on a grid in BIRTH space, so their shape stays stable while they travel.
vec2 grainDrift(vec2 h, float age) {
  return vec2(0.10, 0.05) * age + curl2(h * 3.0) * 0.012 * age;
}
vec3 shedGrains(vec2 p, float t, float life, float density, vec3 tint) {
  vec3 acc = vec3(0.0);
  float gs = 0.012;
  for (int k = 0; k < 8; k++) {
    float fk = float(k);
    float cyc = t / life + fk / 8.0;
    float age = fract(cyc) * life;
    float gen = floor(cyc);
    vec2 h = p - grainDrift(p, age);
    h = p - grainDrift(h, age);
    vec2 cell = floor(h / gs);
    vec3 hh = hash32(cell + gen * 7.31 + fk * 13.7);
    if (hh.z > density) continue;
    vec2 c = (cell + 0.5 + (hh.xy - 0.5) * 0.5) * gs;
    if (logoP(c) < 0.5) continue;
    vec2 f = h - c;
    float sz = gs * 0.3;
    acc += tint * exp(-dot(f, f) / (sz * sz)) * (1.0 - age / life) * smoothstep(0.0, 0.08 * life, age);
  }
  return acc;
}
```
**Front-driven birth (dissolve or burn).** When a grain is born the moment a front passes it, age depends on *where* it was born, so iterate the age itself:
```
a = (prog - front(h)) * T;   h = p - drift(h, a);   // twice
```
Then accept the grain only if `a` falls inside this layer's slot. Both `fluid-ash` and `fluid-ember` work this way (EFFECT-RULES 5.2). Do not give grains a per-cell random age: the fixed point then lands in neighbouring cells and grains blink out.

## 11. Log-polar scrolling-grid sparks
**Use:** vortex, warp or tunnel sparks. In (u = log r, v = turns) space every grain moves at constant velocity. The spiral is therefore self-similar, and a grain's birth point is exactly `centre − vel·age`, which you can test against the logo with no iteration (EFFECT-RULES 5.3).
```glsl
// Log-polar scrolling grid: in (u = log r, v = turns) every grain moves at constant velocity, so the
// spiral is self-similar and a grain's birth point is exactly (centre − vel·age) → testable on the logo.
vec3 spiralSparks(vec2 p, float t, float life, vec3 tint) {
  float r = max(length(p), 0.001);
  vec2 lp = vec2(log(r), atan(p.y, p.x) / 6.2831853);
  vec2 vel = vec2(0.30, 0.06);
  vec3 acc = vec3(0.0);
  for (int k = 0; k < 4; k++) {
    float fk = float(k);
    float rows = 64.0 + 16.0 * fk;
    vec2 cs = vec2(0.05 + 0.01 * fk, 1.0 / rows);
    vec2 q = lp - vel * t;
    vec2 cell = floor(q / cs);
    vec2 key = vec2(cell.x, mod(cell.y, rows));
    vec3 h = hash32(key + fk * 17.0);
    if (h.z > 0.7) continue;
    float age = fract(t / life + h.x) * life;
    vec2 birth = (cell + 0.5) * cs + vel * (t - age);
    vec2 pb = exp(birth.x) * vec2(cos(birth.y * 6.2831853), sin(birth.y * 6.2831853));
    if (logoP(pb) < 0.5) continue;
    vec2 f = (fract(q / cs) - 0.5) * cs * vec2(r, 6.2831853 * r);
    float sz = 0.0025;
    acc += tint * exp(-dot(f, f) / (sz * sz)) * (1.0 - age / life);
  }
  return acc;
}
```
- `mod(cell.y, rows)` hides the seam at ±180°, where `atan` wraps.
- `* vec2(r, 2πr)` converts the cell-local offset back to screen units, so grains stay round at every radius.
- For a DJ variant, add `kick` to `vel.x` (bursts outward on the kick).

## 12. Truchet tiling
**Use:** a pattern fill inside the ink (brand: subtle, inside the letters only) or a maze that re-rolls on the beat (DJ).
```glsl
// Truchet quarter-arc tiles, randomly flipped per cell. Returns distance to the nearest arc
// in cell units (0 on the line). Change `seed` to re-roll the maze.
float truchet(vec2 q, float seed) {
  vec2 f = fract(q) - 0.5;
  if (hash12(floor(q) + seed) > 0.5) f.x = -f.x;
  float d = min(length(f - 0.5), length(f + 0.5));
  return abs(d - 0.5);
}
```
```
// two mazes alternate within each beat (locked to the downbeat); the slow TIME term makes the pair evolve
float d = truchet(p * 28.0, floor(uBeat * 2.0) + 3.0 * floor(TIME * 0.25));
float line = 1.0 - smoothstep(0.08, 0.08 + 28.0 * 1.5 / RENDERSIZE.y, d);
col = lg.rgb * lg.a * (0.35 + 0.65 * line);      // maze carved into the letters; keep 0.35 so it reads at rest
```

## 13. Moiré reveal
**Use:** a hidden-image reveal. Inside the logo, the second grating is phase-shifted by π. The logo appears as an inversion that swims while grating B rotates, and locks in as `angB → 0`.
```glsl
// Moiré reveal: two fine gratings; inside the logo grating B is phase-shifted by π, so the logo
// shows as a dark/bright inversion that swims while B rotates and locks in when angB → 0.
float moire(vec2 p, float lines, float angB, float logoMask) {
  float a = 0.5 + 0.5 * sin(p.y * lines * 6.2831853);
  vec2 pb = rot2(angB) * p;
  float b = 0.5 + 0.5 * sin(pb.y * lines * 6.2831853 + logoMask * 3.14159265);
  return a * b;
}
```
- Call it with `moire(p, 60.0, (1.0 - reveal) * 0.12, logoCov5(p, 0.003))`.
- Mask the result to the logo neighbourhood (`smoothstep(0.0, 0.3, logoField(p, 0.16).x)`). The test version used a fixed disc, which touched the frame edges and left border alpha at 0.07.
- Keep `lines` at or below about 60 per frame height. Finer gratings alias in the 480×270 GIF and on camera-captured LED walls.

## 14. Vogel-disc blur (focus pull, halo)
**Use:** both. A focus-pull reveal (brand: blurred logo sharpens into place) or a soft glow around the ink (DJ: kick-driven bloom). **Cost:** 12 taps.
```glsl
// Golden-angle (Vogel) disc blur of the logo, premultiplied rgba. Radii go with sqrt(i) so any tap count
// covers the disc evenly and there are no ring bands. r = 0 collapses every tap onto p: the untouched logo,
// so the rest state stays legible. Rotate the spiral per pixel (rot) to turn residual banding into fine grain.
vec4 vogelBlur(vec2 p, float r, float rot) {
  vec4 acc = vec4(0.0);
  for (int i = 0; i < 12; i++) {
    float fi = float(i);
    float a = fi * 2.3999632 + rot;
    vec4 s = logoRGBA(p + r * sqrt((fi + 0.5) / 12.0) * vec2(cos(a), sin(a)));
    acc += vec4(s.rgb * s.a, s.a);
  }
  return acc / 12.0;
}
```
```
vec2 px = isf_FragNormCoord * RENDERSIZE;                              // not gl_FragCoord: TD and hosts differ
float rot = 6.2831853 * fract(52.9829189 * fract(dot(px, vec2(0.06711056, 0.00583715))));   // interleaved gradient noise
// focus pull: blurred and dim at reveal = 0, sharp at 1
vec4 b = vogelBlur(p, 0.05 * (1.0 - reveal), rot);
// kick halo: blurred coverage outside the ink, tinted; the untouched logo is composited on top (§2)
float halo = vogelBlur(p, 0.03 + 0.03 * kick, rot).a * (1.0 - logoP(p));
```
- Radius is in height units, like every other distance here. Above about 0.06 twelve taps start to show as discrete copies of the logo; for a wider blur raise the constant loop bound and the two `12.0` divisors together (loop bounds must stay constant).
- The halo must reach 0 at the frame edge by construction (it is a blur of the logo, which is 0 outside the plate), so it does not need `edgeGlow`.
