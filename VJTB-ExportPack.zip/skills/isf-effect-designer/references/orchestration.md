# Parallel orchestration: designing N effects with sub-agents

Use this when one request means more than about 3 effects, or several categories ("make 10 more effects", "a DJ pack for every category"). The rule is **one designer sub-agent per category, each in its own git worktree, with its own Vite port, editing only `src/effects/ext/<category>.ts`.** An independent reviewer critiques the GIF sheets, and the orchestrator merges.

Why worktrees:
- Two agents in one tree trigger Vite HMR reloads in each other's QA runs. A reload drops `__verify` mid-sweep, and the half-finished numbers mix two shader versions.
- Two agents in one tree also collide on edits.
- Separate trees with separate ports make every render deterministic and private to its author.

Why the ext files:
- `registry.ts` already spreads `FLORA_EXT`…`STING_EXT`, so each designer owns exactly one file and merges cannot conflict.

## Roles and models
| Role | Model | Why |
|---|---|---|
| Orchestrator | the session model | Coordination only. Keep its context free of shader code. |
| Researcher (optional, first) | **Sonnet or Haiku** via `vfx-effect-research`. Never Opus for web search. | Search is breadth, not depth. Opus there is wasted spend, and the user has asked for this explicitly. |
| Designer, one per category | **Opus, high effort** | Shader maths, aesthetic judgement, and long verification loops. A weak design costs whole render rounds, and each round takes minutes in SwiftShader. |
| Reviewer, never the author | **Sonnet, high effort** | Judges pixels against a fixed template. Independence matters more than raw power: the author reads intent into frames, while the audience only sees pixels. |

Sizing:
- Run at most 3 effects per designer and at most 5 designers at once.
- SwiftShader is CPU-bound, so five parallel Playwright renders slow each other 2–4×. Run the heavy jobs (`strobe_check.py --presets all`, full `qa_effects.py`) after review, not during the first draft.

## 1. Set up (orchestrator)
```bash
ROOT=/home/claude/vjtb-studio
git -C $ROOT status --short          # worktrees check out HEAD: uncommitted src/, scripts/ AND .claude/skills/ changes
                                     # are NOT in them. Commit (or ask the owner to) everything designers need first.
declare -A PORT=([flora]=5181 [fluid]=5182 [metal]=5183 [glitch]=5184 [sting]=5185)
for c in flora fluid metal glitch sting; do         # only the categories you need
  git -C $ROOT worktree add -b fx/$c $ROOT-wt-$c HEAD
  ln -s $ROOT/node_modules $ROOT-wt-$c/node_modules  # no npm install per tree
  (cd $ROOT-wt-$c && nohup npx vite --port ${PORT[$c]} --strictPort > .vite.log 2>&1 &)
done
for c in flora fluid metal glitch sting; do curl -s -o /dev/null -w "$c %{http_code}\n" http://localhost:${PORT[$c]}/verify.html; done   # expect 200
```
- `--strictPort` makes a port clash fail loudly instead of silently serving the wrong tree.
- `.vite.log`, `verify-out/` and the `node_modules` symlink are all gitignored, so `git status` in a worktree shows only the designer's file.
- This exact sequence (worktree, symlink, port, every tool with `--url`, then cleanup) was dry-run on 2026-10-16.
- The main tree keeps :5173 for other agents.

**Reference-renderer check in a worktree.** `scripts/isf_reference_check.py` is hard-wired to `localhost:5173`. Run `python3 scripts/isf_reference_check.py --help`. If it lists `--url`, use that. Otherwise run a port-patched copy from the worktree root:
```bash
# <port> = your worktree port; <scratch> = your scratch directory (not the repo)
sed "s#localhost:5173#localhost:<port>#" scripts/isf_reference_check.py > <scratch>/refcheck_<port>.py && python3 <scratch>/refcheck_<port>.py
```

## 2. Designer prompt (one per category; spawn all in one turn)
```
Load and follow <ROOT>-wt-<cat>/.claude/skills/isf-effect-designer/SKILL.md.
Worktree: <ROOT>-wt-<cat> (branch fx/<cat>). Dev server: http://localhost:<port> is already running.
Do not start another server and do not use :5173.
Pass --url http://localhost:<port>/verify.html to every tool. Use absolute paths, because cwd resets between calls.
Typecheck with `npx tsc -p tsconfig.app.json --noEmit` (the -b build info lives in the shared node_modules).
Edit ONLY src/effects/ext/<cat>.ts. Do not edit glslLib.ts, registry.ts, the base category file,
VISUAL-QA.md or scripts/. If you need a helper, define it locally in your glsl string, prefixed with your
effect slug, and propose it for the library in your report.
Brief: <n> effects. Audience: <brand|dj|both each>. Look and genre targets: <...>. Concept cards: <paste>.
Run the full verification loop. Then STOP and report:
  ids; the design brief per effect; absolute paths of every gifsheet, controls sheet and strobe json;
  qa numbers (dead/weak controls, audio Δ, flicker60, border, strobe flashes/s); open questions.
Do not commit until the reviewer says SHIP.
```

## 3. Reviewer prompt (a fresh agent, not the author)
```
You are an independent visual reviewer for VJTB Stinger Studio. You did not write these effects.
Load <worktree>/.claude/skills/vjtb-visual-qa/SKILL.md and use its critique template, including the
audience and strobe lines. Audience per effect: <id → brand|dj|both>.
Open at full size with your image tool: <gifsheet paths, both logos for "both">, <controls sheets>.
Read: <qa json>, <strobe json>.
Judge the pixels BEFORE reading any shader source. Afterwards you may read it to suggest a concrete fix.
For each effect return: the template answers; fixes ranked blocker / major / minor, each citing the
frame number or controls-sheet row as evidence; verdict SHIP or FIX. Do not edit files.
```

## 4. Fix rounds
- Send the reviewer's critique back to the designer. Use `SendMessage` to the same agent if your harness supports it; otherwise spawn a new designer on the same worktree with the previous report and the critique.
- The designer fixes, re-renders the same sheets (a new `--tag`, e.g. `<id>-r2`), and reports before/after numbers.
- Run the reviewer again. The minimum is two rounds per new effect.
- After round 3 without SHIP, escalate to the user with the sheets rather than looping. The concept may need to change, not the code.

On SHIP, the designer runs:
```bash
git -C <worktree> add src/effects/ext/<cat>.ts && git -C <worktree> commit -m "fx(<cat>): <names>"
```

## 5. Merge and verify (orchestrator, main tree on :5173)
```bash
for c in <cats>; do git -C $ROOT merge --no-ff fx/$c -m "fx($c): merge designer branch"; done
cd $ROOT
npm run typecheck && npm run build
python3 scripts/visual_check.py --compile-only                          # all effects × 4 targets
python3 scripts/isf_reference_check.py                                  # 0 failures
python3 .claude/skills/isf-effect-designer/scripts/export_fs.py --only <new ids>
python3 scripts/qa_effects.py --only <new ids> --tag merged --logo auto
python3 .claude/skills/vjtb-visual-qa/scripts/strobe_check.py --only <new ids> --tag merged   # all presets
```
- A merge conflict means a designer edited a shared file. Keep the main-tree version of that file and ask the designer to move the change into its ext file.
- Append each approved critique (with its round history) to `VISUAL-QA.md` yourself. A single writer avoids append conflicts.
- Pass any proposed `glslLib` helpers to whoever owns `src/isf/`. Promote a helper only after a second effect needs it.

## 6. Clean up
```bash
for c in <cats>; do
  pkill -f "[v]ite --port ${PORT[$c]}"       # the [v] stops pkill -f from matching (and killing) this shell itself
  git -C $ROOT worktree remove $ROOT-wt-$c && git -C $ROOT branch -d fx/$c
done
```
`worktree remove` refuses while tracked files have uncommitted changes. That means a designer never committed, so check before you reach for `--force`. Ignored files (`verify-out/`, `.vite.log`, the symlink) do not block it, and the shared `node_modules` target is untouched.
