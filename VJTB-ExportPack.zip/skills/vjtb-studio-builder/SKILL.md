---
name: vjtb-studio-builder
description: Build, extend or recreate VJTB Stinger Studio, the Vite/React/Three.js web app that previews logo reveals and stingers and pushes them live to TouchDesigner and Resolume. Use it for any work on the app itself (not on a single effect's shader): adding a host (Notch, Millumin, VDMX, MadMapper...), adding an effect category, sync hub, OSC bridge or TouchDesigner callbacks changes, user presets and the params-only "Send preset", viewport, deck or inspector UI, audience tags and the DJ sample logo, the verification suite, running several agents in parallel worktrees, or rebuilding a VJ web app that drives TouchDesigner/Resolume from this spec. Trigger even if the request never names the project, whenever someone wants a browser tool that sends live shaders or parameters to a VJ or media server.
---

# VJTB studio builder

You are changing the application, not an effect. Effects have their own skill (`isf-effect-designer`), QA has `vjtb-visual-qa`, host facts have `vjtb-host-setup`. Read `AGENTS.md`, then `REALITY-CHECK.md` (every host fact in this repo was checked against vendor docs; the project spec was wrong about Arena's API version), then this file. Open `references/architecture.md` when you need a file-level map, message formats or the rebuild-from-spec order.

## 1. The picture
```
EffectDef (src/effects/*.ts): params + presets + one ISF body
  │ composeISF(effect, values, 'spec' | 'wire')      helpers tree-shaken from src/isf/glslLib.ts
  ▼
ISF 2.0 source ─┬─► ISFRenderer (runtime.ts, Three.js WebGL2)  → the preview and the thumbnails
                ├─► export: spec .fs · Wire-safe .fs · zip · bridge file drop
                ├─► validate.ts: WebGL2 | strict GLSL ES 1.00 | TD shim (verify.ts adds Wire-safe)
                └─► toTouchDesigner (tdExport.ts) → GLSL TOP pixel shader(s) → hub.push() → td/vjtb_webserver_callbacks.py
Live: store.values + automation (LFO) + drivers (audio, cue, beat) ──resolveValues──► live.values
        ├─► shader uniforms, every frame
        └─► hub.tick(): TD "params" · OSC through the bridge · Resolume set-by-id (change-detected, rate-limited)
```
The preview runs the same source that is exported. Keep it that way: a preview-only code path means the show machine shows something nobody ever reviewed.

## 2. Invariants (each exists because breaking it hurt)
1. **One ISF source, many targets.** Do not special-case the preview. If a host needs something else, translate (as `tdExport.ts` does), never fork the effect.
2. **No per-frame React state.** `useStudio` (zustand) holds intent: selection, values, autos, logo, config, statuses. `live` (same file) is a plain mutable object the engine loop writes each frame (values, audio, fps, time, cue). UI reads `live` from `requestAnimationFrame` / `setInterval` into DOM refs (see `Transport` and `SyncBar`). Calling `set()` or subscribing a component to `live` inside the loop re-renders at 60 Hz and starves the GPU thread.
3. **Host facts come from REALITY-CHECK.md.** A new host or endpoint gets a row there (claim, verdict, source) before any code. Never write an API from memory.
4. **A `ParamDef` is a public contract.** Its `name`, `label`, `type` and range appear as the ISF input, the TD uniform (`<name>_f` for bool/long/event), the OSC address (`/vjtb/<effectId>/<name>`), the Resolume match (`hub.resolumeParam` matches normalized label or name, and Wire appends option text to long labels, hence the `startsWith`) and the user's saved presets. Renaming one breaks a show file. If you must, update `mock_hosts.mjs`, `e2e_sync.py` and the docs in the same change.
5. **The hub never blocks the loop.** Sockets reconnect with backoff, failures become status dots and toasts, and `tick()` returns early when nothing changed.
6. **The bridge stays small.** See section 3.
7. **`AGENTS.md`, `docs/EFFECT-RULES.md` and the skills ship inside the app.** `?raw` imports in `Inspector.tsx` and `prompts.ts` embed the first two in the export zip and the "Author a new effect" prompt. The app branch with user presets also adds `src/prompts/skills.ts`, which bundles the five `SKILL.md` files and their `references/*.md` for the AI Wizard tab and the export pack (`scripts/` and `evals/` are not bundled). So keep a skill's folder name equal to its `name:`, keep front matter to single-line `name:` and `description:`, and keep every `references/` path a skill mentions real. Rebuild after editing any of them: a renamed or deleted file breaks the build.

## 3. Sync hub and bridge security model
`src/sync/hub.ts` owns three connections (`Conn`: WebSocket, exponential backoff up to 10 s) and two operations:
- **`tick(effect, values, force?)`** every frame: for each parameter whose value changed (rounded to 1e-4) send, at most `rateHz` times per second, (a) TD `{t:'params'}`, (b) OSC packets through the bridge (TD `/vjtb/<id>/<name>`; Resolume `/composition/layers/N/dashboard/link1..8`, first eight float params normalised 0..1), (c) Resolume `{"action":"set","parameter":"/parameter/by-id/<id>","value":<native>}`. Audio drivers are skipped unless `streamAudio` is on.
- **`push(...)`**: logo PNG + translated shader passes + uniform table to TD (it destroys and rebuilds `pass*`, `shader_*`, `fb_*` and `out1`), `.fs` / `.frag` files to the bridge, then `last = {}` and a forced `tick`. Push is heavy and visible on air.

Bridge (`bridge/core.mjs`, a Vite dev plugin at `/__vjtb` and a standalone CLI that binds 127.0.0.1 only):
- **Origin check.** Browser origins must be loopback unless started with `--allow-origin` (or `VJTB_ALLOW_ORIGINS`). A missing Origin header is allowed on purpose: CLI tools and AI agents have none. So any local process can talk to it.
- **UDP out only to loopback or private LAN** (`isPrivateHost`), ports 1..65535. This stops a web page from turning the bridge into a public UDP cannon.
- **Writes only into the two configured folders**, using `path.basename`, a sanitised name, and an extension allow-list (`.fs .frag .json .py .txt .md .png`). Never add executables or script types to that list.
- **Messages are data.** The TD callbacks parse JSON and set parameters; they never `exec` payload text, and the logo goes to a fixed filename.
- Known gap: the standalone server's HTTP status page answers any origin with counters and the configured folder paths.

## 4. Recipes
### Add an effect
Not here: use `isf-effect-designer` (concept, GLSL, presets, QA). For several at once, section 6.

### Add a category
1. `types.ts`: add the id to `CategoryId`. `common.ts`: add a `CATEGORIES` entry (label, `short`, colour, blurb); the deck order, jump rail and inspector header follow that array.
2. Create `src/effects/<cat>.ts` exporting the category's fixed param set (like `FLORA`, `FLUID(tint)`, `METAL(tint)`, `GLITCH`, `STING`) and its `EffectDef[]`.
3. Create the **extension slot** `src/effects/ext/<cat>.ts` (`export const <CAT>_EXT: EffectDef[] = []`) and spread both into `BUILTIN_EFFECTS` in `registry.ts`. One owner per ext file means parallel designers never conflict on the registry.
4. Anything keyed on `category === 'sting'` (thumbnail state in `engine.ts`, `take()` in the store, `Transport`, `qa_effects.py probe_for`, `visual_check.py span_for`) needs a decision for the new category. Grep `'sting'`.
5. If the category needs a Tailwind colour token, add it to `tailwind.config.js` (`cat.*`).
6. Add the category to the table in `isf-effect-designer` (section 2) and describe its probe state in `VISUAL-QA.md` if it differs from the default.

### Add a host
1. **Research first.** Search vendor docs, write the facts and sources into `REALITY-CHECK.md`. Mark what you could not verify.
2. **Pick the transport.** Browser WebSocket goes in the hub as a new `Conn`. UDP (OSC, Art-Net) and files go through the bridge: a new `exportDirs` target plus CLI flag and env var. Never open raw sockets from the page.
3. **Pick the shader path.** A host that loads ISF reuses `composeISF`. A host that does not needs a translator in `src/isf/` (model it on `tdExport.ts`) and a fourth compile target in `validate.ts`, `verify.ts compileAll` and `visual_check.py`.
4. **State and UI.** Add `SyncConfig` fields with defaults (stored under `vjtb.sync.v1`, merged over defaults on load, so old saves still work), a `status` entry, a `Host` tile in `SyncBar`, a section in the Sync panel, an AI Setup prompt in `prompts.ts` that states only verified facts, and a note about port collisions (TDMCP vs the Web Server DAT on 9980 is the precedent).
5. **Map parameters** inside `tick()` and `push()` with the same change detection. Respect the host's native ranges; OSC is 0..1.
6. **Test doubles before real hosts.** Extend `scripts/mock_hosts.mjs` with a fake built from the official spec's shapes, assert payloads in `e2e_sync.py`, and if you ship host-side script code, stub the host API like `test_td_bridge.py`.
7. Update the README host table and the `vjtb-host-setup` skill. Say plainly that a live instance was not available if you had none.

### User presets and "Send preset"
Built-in presets are immutable (`EffectDef.presets`). A **user preset** is a named snapshot of one effect's parameter values plus the LFO state at save time. Names as built on the app branch (this feature landed after the skill was written, so grep `userPreset` in your tree before relying on them): `src/state/presets.ts` (`UserPreset`, `UserPresets = Record<effectId, UserPreset[]>`, localStorage key `vjtb.presets.v1`, JSON import and export of kind `vjtb-presets`), store fields `userPresets` and `userPreset` (index of the applied one, or null) with `applyUserPreset`, and deck items from `deckItems(effects, userPresets)` in `registry.ts`. They are applied the way `selectPreset` applies a built-in, and storage reads and writes are try/catch guarded.

**Send preset = parameters only.** `engine.sendPreset()` calls `hub.pushParams(effect, values)`, which sends every parameter of the current effect through `tick(effect, values, true)`: TD `params`, OSC, Resolume set-by-id. `hostPresence(state)` says which live hosts already hold the effect (`ready` when a snapshot is enough), and a host without it gets a toast pointing at Push to Live Host. It must not send `push`, write `.fs` files or resend the logo. Reason: a push destroys and recreates the TD network and rewrites the Wire/Arena shader files, which hitches the output and can reset host-side state; changing a preset does not need any of that. Rules:
- Push only when the shader changes (new effect, edited GLSL, new resolution).
- If the host has no matching effect yet, say so in a toast instead of silently sending nothing.
- "Reset to preset" in the UI is a local action. It reaches hosts only through `tick`.

### Viewport is program-only
The 3D LED-wall stage (truss, floor reflection, beams, bloom, LED pitch, OrbitControls) was removed at the user's request. The viewport shows the flat 1:1 program output with an optional alpha checker, at the chosen render resolution. Do not bring the stage back, and do not add view modes without being asked. If `engine.ts` in your tree still has stage code, the removal is on a branch you have not merged; do not build on it.

### Audience tags and the DJ sample logo
`EffectDef.audience` is `'brand' | 'dj' | 'both'` (optional in the type; `deckItems` treats a missing tag as `both`). The deck's audience filter (`audienceFilter` in the store, an `AudienceBadge` on each tile) reads it, and it drives which logo QA uses: `--logo auto` picks the NOVA DJ mark for `dj` effects and the VJTB corporate mark otherwise. Both marks are drawn from `Path2D` data in `engine/logo.ts` (no fonts, so renders are identical on every machine); `LogoSource.kind` is `default | dj | svg | raster`, and `verify.ts` exposes `setLogo('brand'|'dj')`. Check `EffectDeck.tsx`, `Viewport.tsx` and `store.ts` for what else exists. Audience rules are in `docs/EFFECT-RULES.md` section 8.

### UI changes
Dark, dense, Tailwind tokens (`ink-*`, `sig`, `tally-*`, `cat-*`). The page is a three-column grid at `lg` and a stack below, so test 390 px and 1280 px wide. Deck motion is written straight to the DOM in rAF; keep it that way.

## 5. Verification suite
Keep `npm run dev` running on :5173 in the main tree (use your own port in a worktree and pass `--url`). Run what your change touches, and say which you ran.

| Check | Command | Pass means |
|---|---|---|
| Types | `npm run typecheck` (worktree: `npx tsc -p tsconfig.app.json --noEmit`) | clean |
| Build | `npm run build` | `tsc -b` and `vite build` succeed |
| Compile, 4 targets | `python3 scripts/visual_check.py --compile-only` | every effect ✓ on WebGL2, ES 1.00, TD, Wire-safe |
| Official ISF renderer | `python3 scripts/isf_reference_check.py` | 0 failures (hard-wired to :5173; see `orchestration.md` for the port-patched copy) |
| Static lint | `python3 .claude/skills/isf-effect-designer/scripts/export_fs.py` | exports spec and Wire files and runs `scripts/isf-lint.mjs`; exit 0 |
| Control sweep | `python3 scripts/qa_effects.py --only <ids> --tag <run> --logo auto` | no DEAD, audio Δ ≥ 1.5 |
| GIF sheet | `python3 scripts/visual_check.py --gif --only <ids> --out verify-out/gif` | opened and read at full size |
| `--logo` | `visual_check.py --logo dj` / `--logo-plate` | check `both` effects with both marks |
| Strobe | `python3 .claude/skills/vjtb-visual-qa/scripts/strobe_check.py --only <ids> --presets all --tag <run>` | exit 0 (≤ 3 flashes/s) |
| Sync end to end | `python3 scripts/e2e_sync.py` (hard-wired to :5173; starts `mock_hosts.mjs` itself, so do not start it separately) | all PASS: TD push, logo, params, Resolume set-by-id, OSC |
| TD callbacks | `python3 scripts/test_td_bridge.py` (needs `verify-out/e2e-td-push.json` from the e2e run) | all PASS against the stubbed TD API |
| UI | Playwright screenshot of `http://localhost:5173/` | see below |

**UI screenshots under software GL.** SwiftShader renders about 1 fps, which starves the main thread; Playwright's own clicks then time out on actionability checks. Dispatch clicks from the page and wait on state, not time:
```python
page.goto('http://localhost:5173/'); page.wait_for_selector('aside[aria-label="Inspector"]', timeout=90000)
page.evaluate("() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Export').click()")
page.wait_for_function("() => window.__studio.getState().panel === 'export'")   # wait on state, not time; __studio exists in dev only
page.screenshot(path='verify-out/ui-export.png')
```
Then open the PNG and read it. Never call UI work done from a passing typecheck.

## 6. Parallel orchestration (several agents, one repo)
Use it when work splits into disjoint file sets (five category designers; app UI plus bridge plus scripts). Details and prompts: `.claude/skills/isf-effect-designer/references/orchestration.md`.
1. **Commit the baseline first.** Worktrees check out `HEAD`; uncommitted skills, scripts and src are invisible to them.
2. **Manual worktrees, not the agent harness's built-in worktree isolation.** That option failed in this project, and two agents in one tree broke each other's QA runs through Vite hot reload.
   ```bash
   git worktree add -b wip/<area> ../wt/<area> HEAD && ln -s $PWD/node_modules ../wt/<area>/node_modules
   (cd ../wt/<area> && nohup npx vite --port 518<n> --strictPort > .vite.log 2>&1 &)
   ```
   One port per agent (5181, 5182...), `--strictPort` so a clash fails loudly, every tool called with `--url http://localhost:518n/verify.html`, absolute paths (cwd resets between calls).
3. **Disjoint ownership.** Each agent edits only its files (an ext slot, or `src/ui/**`, or `bridge/**`). Shared files (`glslLib.ts`, `registry.ts`, `store.ts`, `VISUAL-QA.md`) have one owner, who takes proposals from the others.
4. **Independent critics.** The critic is never the author. It judges pixels first (sheets, strobe beat sheets, screenshots), then may read code, and returns SHIP or FIX with ranked findings. See `vjtb-visual-qa`.
5. **The orchestrator merges** with `git merge --no-ff`, keeps the main-tree version of any shared file in a conflict (and asks the author to move the change), then runs the whole suite on :5173. Remove worktrees and kill the Vite servers afterwards (`pkill -f "[v]ite --port 518n"`).
6. Heavy jobs (full `qa_effects.py`, `strobe_check.py --presets all`) run after review, not during drafting: five SwiftShader renders at once slow each other 2–4×.

## 7. Lessons learned (do not relearn these)
- **A black first render looked like an art problem.** The runtime compiled GLSL3 while bodies wrote `gl_FragColor`. Check pixel extrema before critiquing any frame. `ISFRenderer` sets no `glslVersion` on purpose, so Three adds its GLSL1 compat defines.
- **The ISF-JS reference parser splits `IMG_*PIXEL(...)` arguments on every comma.** All 25 effects failed it until sampling went through `imgClamp()`. Passing in our own WebGL2 runtime proves nothing about other hosts, so keep `isf_reference_check.py` and `isf-lint.mjs` as separate gates.
- **A Vite hot reload mid-run drops `window.__verify`.** Every script wraps calls in `ev()`, which retries up to 4 times waiting for `document.title === 'ready'`. A reload also resets per-page state such as the selected logo, so pass it explicitly on every call. Worktrees remove the cause.
- **SwiftShader blocks simulated clicks** (section 5). Use JS clicks and state waits.
- **Haze floors covered the whole frame** (Vortex, Iris). Glows go through `edgeGlow`, never bare `exp(-abs(sd)*k)`. Check the `border` alpha stat and the frame edge.
- **Dead controls shipped** (baseline: 26 DEAD and 35 WEAK of 175 controls). The sweep exists to catch them; reinterpret a control rather than leave it inert.
- **Pillow merges identical consecutive GIF frames** into one longer frame, so a GIF has fewer frames than were rendered and index-based time labels lie. Review sheets are built from the GIF file and labelled from its durations.
- **Review sheets go stale.** Re-render and compare if sources changed after the render. Reusing a `--tag` overwrites `qa-<tag>.json`; snapshot first.
- **Baselines can be inflated by the bug being fixed** (Flash Wipe's audio Δ fell from 26.7 to 2.5 when idle frames stopped drawing). Do not treat old numbers as targets.
- **The probe misses transients.** Shake lives for 0.1 s after the hit and an accent colours one bar. Sweep Δ 0.9 can be a probe artefact; re-measure where the control acts before arguing either way.
- **Metrics cannot see the worst defects** (spill at the frame edge at 100% growth, mesh-like ash, a lost emblem). Open the sheets at full size.
- **Live hosts were never available here.** Everything host-side was verified against stubs and mocks built from vendor specs. Say so in every report, and tell the user to run `e2e_sync.py` and press Push on the show machine before doors.

## 8. Done means
Tools you ran are named with their results; UI or visual work was opened and read at full size; new host facts are in `REALITY-CHECK.md`; `AGENTS.md`, the README map and the skills still describe what the code does; nothing outside your ownership changed; and the report says what was not verified.
