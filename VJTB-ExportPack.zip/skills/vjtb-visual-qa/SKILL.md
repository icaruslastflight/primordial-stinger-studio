---
name: vjtb-visual-qa
description: Critical visual QA loop for VJTB shader effects. Render GIFs, frame sheets and beat sheets, sweep every control, measure flicker, audio response, alpha and strobe safety, judge each effect against its audience (brand logos on legibility and premium feel, DJ logos on impact and beat response), write a per-effect critique, fix, re-render. Also defines the independent-critic workflow, where the reviewer is never the author. Use whenever an effect is created or changed, when someone asks for a visual check, review, critique or "is this good enough to ship", and before merging any designer's branch.
---

# VJTB visual QA: be the harshest reviewer in the room

Metrics find dead controls. Only looking finds ugly. Do both, every time. If you wrote the effect, you are the wrong person to approve it: section 6 says how to get a real second opinion.

## 1. Render
```bash
npm run dev   # keep running (in a worktree: your own port, and add --url http://localhost:<port>/verify.html to every command)
python3 scripts/visual_check.py --gif --only <ids> --out verify-out/gif            # --logo auto by default
python3 scripts/qa_effects.py --only <ids> --tag <run>
python3 .claude/skills/vjtb-visual-qa/scripts/strobe_check.py --only <ids> --presets all --tag <run>
```
- `<id>-gifsheet.png` is built from the GIF file itself, so you review what ships. It samples every 2nd frame across one LFO or cue cycle.
- `qa/<run>/<id>-controls.png` shows every control at min (left) and max (right), plus audio from silence to a kick.
- `qa/strobe-<run>/<id>-p<N>-beats.png` is the **beat sheet**: every 4th frame at 15 fps, labelled with the 124 BPM beat phase (gold = the first 15% of a beat). The GIF sheet samples about every 0.33 s and aliases beat-locked looks, so judge DJ beat response here.
- `--logo auto` gives `dj` effects the NOVA sample mark and everything else the VJTB mark. Check `both` effects with both (`--logo dj`, which adds a `-dj` suffix to the file names). `visual_check.py --logo-plate` writes the plates themselves.

## 2. Sanity before judging
- If a frame is entirely black or empty, check the pixel extrema before you critique anything. The first render pass of this project was all black because of a GLSL3 `gl_FragColor` mismatch, not because of the art.
- Stingers: confirm the frames before progress 0 and after progress 1 are empty.
- If sources changed after the render, re-render. Sheets go stale.

## 3. Pick the audience, then judge against it
| Audience | Logo | Judge it on |
|---|---|---|
| **brand** | VJTB mark | Legibility at rest and exact silhouette. Premium feel: believable materials (metal, glass, ink, light), restrained eased motion, colours from the tint. Would a sponsor sign off on this on a stage screen? |
| **dj** | NOVA mark | Impact and beat response. Does the kick change *structure* (scale, displacement, cuts, segment count) and not just brightness? Is the look locked to `uBeat` and does the logo land clean on the downbeat or the hold? Genre fit (techno cold mono, hardstyle red and black, psytrance UV/acid, house warm). High contrast. |
| **both** | both marks | The calm preset reads as brand, the aggressive one as DJ, and neither breaks the other's rules. |

Gaudy is fine for a DJ look and a fail for a brand look. A tasteful brand look with no punch is a fail for a DJ.

## 4. Critique template (answer every line, per effect)
1. **Read at rest.** Is the logo fully legible when growth/fold/crystal is 100%, between glitch bursts, or in a stinger's hold? (DJ: on the downbeat.)
2. **Silhouette.** Is the shape still the brand's, or melted, eroded, jagged or replaced?
3. **Framing.** Is anything drawn outside the effect (haze floors, full-frame dots, idle remnants)? `border` alpha should be about 0 unless the look is intentionally full-frame.
4. **Motion arc.** Does the timeline read as a story (build, peak, release) with no dead stretch?
5. **Detail scale.** Do particles, leaves and cells read at 480×270 and at 1080p, or are they mush or noise?
6. **Colour.** Palette or tint derived? Any sickly or hard-coded hues? Any clipping (`clip`) that is not just a white logo?
7. **Controls.** Any DEAD (<0.4) or WEAK (<1.5)? Fix them, or justify them in VISUAL-QA.md (for example a probe artefact). Re-measure transients where the control acts before arguing.
8. **Audio.** Does a kick change structure, not only brightness?
9. **Flicker.** Is the `flicker60` value justified by the look (static, VHS, particles), or is it aliasing?
10. **Audience fit.** Answer the section 3 question for this effect's audience, with the frame or beat-sheet tile that proves it. Name the logo you used.
11. **Strobe safety.** Section 5 passes for every preset.

## 5. Strobe safety (photosensitivity)
No look may produce more than **3 flashes per second** over a meaningful part of the picture at its default and preset values. A flash is a pair of opposing brightness changes (relative luminance step of at least 0.1 with the darker state under 0.8) or a saturated-red equivalent, covering at least a quarter of a third-of-frame window. This follows WCAG 2.3.1 and ITU-R BT.1702 / Ofcom practice.

`strobe_check.py` renders 2 s at 60 fps with the 124 BPM synthetic kick for each preset, counts flashes per 1 s window and exits 1 on any failure. A full-logo white flash counts. A kick that lifts the whole frame only slightly (under about 0.07 relative luminance) does not.
- Run `--presets all`: the QA sweep looks at preset 0, but the aggressive preset is the one that strobes.
- It is a screen, not a certified Harding/PEAT analysis, and it cannot see tempos or control extremes outside the defaults. If a control can push past 3/s at its max, say so in its `hint`. Broadcast deliverables still need the broadcaster's own flash test.
- Fix by gating on `strobeGate` (isf-effect-designer `references/techniques.md` section 1), lowering amplitude, or moving the flash off the full frame. Do not argue the threshold.

## 6. Independent critic workflow (critic is not the author)
Authors read intent into frames; an audience only sees pixels. So the approving review comes from a fresh agent that did not write the effect.
1. The **author** finishes the loop in section 1, writes down the audience and what the look is trying to do, and stops. The author does not mark it done.
2. The **orchestrator** spawns a **critic** (a new agent; Sonnet at high effort is enough) and gives it: effect ids with audience, absolute paths of gif sheets (both marks for `both`), controls sheets, beat sheets, the QA and strobe JSON, and this skill. Nothing else.
3. The critic opens every sheet at full size and answers the section 4 template **before reading any shader source**. Afterwards it may read the source to propose a concrete fix. It never edits files.
4. It returns, per effect: the template answers; findings ranked **blocker** (illegible at rest, silhouette lost, drawn outside the effect, strobe fail, dead control, black or broken render), **major** (no impact for DJ or no premium feel for brand, audio is only brightness, unreadable at 480×270), **minor**; each with the frame, tile or controls-sheet row as evidence; and a verdict, **SHIP** (no blockers or majors) or **FIX**.
5. The author fixes, re-renders with a new `--tag` (`<id>-r2`), and reports before and after numbers. A fresh critic (or the same one, re-briefed) reviews again. Two rounds minimum for a new effect. After round 3 without SHIP, escalate to the user with the sheets: the concept may be wrong, not the code.
6. One writer appends the approved critique to `VISUAL-QA.md` (the orchestrator), so parallel branches never conflict on the log.

If you are a single agent and cannot spawn one, say so in the log ("self-reviewed") and use a cold read: sheets first, source last, and re-open them after a break in the work. Treat the verdict as weaker.

## 7. Fix, then re-render the same sheets and compare
Log in `VISUAL-QA.md` in this form:
```
### <Effect> `<id>` — round N · <audience> · logo <VJTB|NOVA>
Issues: ...
Changes: ...
Numbers: before → after (controls DEAD/WEAK, audio Δ, flicker60, border, strobe general/red per s)
Verdict: SHIP | FIX (critic: <who>)
```
Two rounds is the minimum for any new effect.
