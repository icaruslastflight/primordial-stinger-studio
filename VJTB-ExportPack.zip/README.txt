VJTB Stinger Studio export pack

isf/            ISF 2.0 spec flavour (long/bool typed inputs)
resolume-wire/  Wire-safe flavour: load into a Wire ISF node, Category=Effect, save to Documents/Resolume Wire/Patches
touchdesigner/  GLSL TOP pixel shaders + Web Server DAT callbacks (vjtb_webserver_callbacks.py)
presets/        parameter presets (JSON): built-ins + your saved presets per effect, and user-presets.json (re-importable in the Export tab)
skills/         AI agent skills (SKILL.md): unzip into .claude/skills/ for Claude Code, or upload them one by one

Resolume Arena does not load .fs files directly; use Wire. TouchDesigner does not load ISF; use the GLSL TOP files.
See AGENTS.md for AI-agent setup instructions.
