# AGENTS.md: guide for AI coding agents working on VJTB Stinger Studio

Read this before you change anything. It applies to Claude Code, Cursor, Codex and any MCP-connected assistant.

## What this project is
VJTB Stinger Studio is a Vite + React + TypeScript + Three.js + Tailwind web app for previewing logo reveals and broadcast stingers and pushing them live:
- **TouchDesigner:** Web Server DAT on port 9980 plus GLSL TOP.
- **Resolume:** Arena WebSocket `/api/v1` on port 8080, OSC on port 7000, and a Wire ISF node.

Every effect is written once as an **ISF 2.0** body. The same source drives the in-browser preview, the `.fs` export, the Wire-safe export and the TouchDesigner GLSL TOP translation.

## Map
| Path | What |
|---|---|
| `src/effects/*.ts` | Effect registry: 5 categories, 3 presets per effect. Each category has an extension slot `src/effects/ext/<category>.ts` for new effects. |
| `src/isf/glslLib.ts` | Shared GLSL helpers (tree-shaken into each export). |
| `src/isf/compose.ts` | EffectDef → ISF 2.0 file (`spec` and `wire` flavours). |
| `src/isf/runtime.ts` | ISF renderer on Three.js (typed inputs, multi-pass, persistent float buffers). |
| `src/isf/tdExport.ts` | ISF → TouchDesigner GLSL TOP translation. |
| `src/isf/validate.ts` | Three-way compile check (WebGL2 / GLSL ES 1.00 / TD shim). |
| `src/sync/hub.ts` | Live sync to TD, Resolume and the OSC bridge, plus Push to Live Host. |
| `bridge/*.mjs` | Node UDP OSC + file-drop bridge (Vite plugin and standalone CLI). |
| `td/vjtb_webserver_callbacks.py` | TouchDesigner Web Server DAT callbacks; builds the GLSL TOP network. |
| `src/prompts/prompts.ts` | Setup prompts shown in the app's AI Setup tab. |
| `scripts/*.py`, `scripts/*.mjs` | Your verification tools (see below). More live in `.claude/skills/*/scripts/`. |
| `docs/EFFECT-RULES.md` | **Binding** authoring rules. |
| `VISUAL-QA.md` | Per-effect critique log. Append to it. |
| `REALITY-CHECK.md` | Host and API facts verified against vendor docs. |
| `.claude/skills/` | Task playbooks for AI agents (see Skills below). |

## Rules (short form; the full set is in docs/EFFECT-RULES.md)
1. **Never guess host APIs.** Use the facts in REALITY-CHECK.md. Arena has no `/api/v2`. TouchDesigner does not load ISF. Vector uniforms are `vec0name` / `vec0valuex`.
2. **Built-in effects are single-pass GLSL ES 1.00.** Convert inputs with `int(float(uX)+0.5)` and `bool(uX)`, and write output only via `vjOut` / `vjOutPM`.
3. **Brand integrity.** The logo must be legible at rest, and nothing may be drawn outside the effect. Use `edgeGlow`, never a bare `exp(-abs(sd)*k)`.
4. **Every control must visibly do something.** QA Δ must be ≥ 1.5, and the audio Δ from silence to a kick must also be ≥ 1.5.
5. **Never mark visual work done from thumbnails or metrics alone.** Open the GIF review sheet at full size.
6. **Declare the audience.** Set `audience: 'brand' | 'dj' | 'both'` on every effect. Brand looks win on legibility and premium feel; DJ looks win on impact and beat response, and the logo must land clean on the beat or the hold. No look may flash more than 3 times a second (`strobe_check.py`). See section 8 of the rules.
7. **Push only when the shader changes.** Switching presets on an effect already in a host sends parameters only ("Send preset"). A push rebuilds the TouchDesigner network and rewrites shader files.
8. **The reviewer is never the author.** Get an independent critique before calling an effect done.

## Tools you must use
```bash
npm run dev                                   # app + bridge at :5173 (keep running for the tools below)
npm run typecheck
python3 scripts/visual_check.py --compile-only                    # all effects × 4 targets
python3 scripts/visual_check.py --gif --only <id> --out verify-out/gif   # GIF + GIF-derived review sheet
python3 scripts/qa_effects.py --only <id> --tag <run>             # control sweep, flicker, audio, alpha stats
node scripts/isf-lint.mjs path/to/file.fs                         # static ISF / portability lint (no GPU)
python3 scripts/isf_reference_check.py                            # official ISF-JS renderer, 0 failures required
python3 .claude/skills/isf-effect-designer/scripts/export_fs.py --only <id>        # export spec + Wire .fs and lint them
python3 .claude/skills/vjtb-visual-qa/scripts/strobe_check.py --only <id> --presets all   # flash screening + beat sheets
python3 scripts/e2e_sync.py                                       # sync end to end against mock hosts (starts them itself)
node scripts/osc-monitor.mjs 7001                                 # watch what the bridge sends
```
`--logo auto` (the default for the visual and QA scripts) judges `dj` effects with the NOVA sample mark and everything else with the VJTB mark; add `--logo dj` to check a `both` effect with both. Every script takes `--url http://localhost:<port>/verify.html` except `isf_reference_check.py` and `e2e_sync.py`, which use :5173.

Then read `verify-out/gif/<id>-gifsheet.png`, `verify-out/qa/<run>/<id>-controls.png` and, for DJ looks, the beat sheet in `verify-out/qa/strobe-<run>/` with your image viewer. Write the critique to VISUAL-QA.md.

## Skills in this repo
`.claude/skills/` holds five task playbooks. Load the one that matches your task:
- `isf-effect-designer`: design, build and QA new or upgraded effects (brand and DJ looks), with a technique cookbook.
- `vfx-effect-research`: time-boxed research for effect ideas before designing. Run it on a cheap model (Sonnet or Haiku), not Opus.
- `vjtb-studio-builder`: build or extend the app itself: add a host or a category, sync hub and bridge, presets, UI, the verification suite, rebuilding from the spec.
- `vjtb-visual-qa`: the critical review loop (GIF and beat sheets, control sweeps, audience judging, strobe safety, independent critic).
- `vjtb-host-setup`: finish TouchDesigner / Resolume / bridge setup, with or without MCP servers; when to push and when to send parameters only.

## Parallel orchestration (several agents at once)
Use it when work splits into disjoint file sets, for example one designer per effect category. Full recipe and prompts: `.claude/skills/isf-effect-designer/references/orchestration.md`.
1. Commit your baseline first: worktrees check out `HEAD`.
2. Give each agent its own git worktree (`git worktree add -b <branch> <path> HEAD`), a symlinked `node_modules`, and its own dev server (`npx vite --port 518n --strictPort`). Do not use the agent harness's built-in worktree isolation (it failed here), and do not let two agents share one tree: Vite hot reload from one agent's edit breaks the other's QA run.
3. Each agent edits only the files it owns (a category's ext slot, or a UI area) and passes `--url` to every tool.
4. A different agent reviews the result (`vjtb-visual-qa`). The author never approves their own work.
5. The orchestrator merges with `git merge --no-ff`, keeps the main-tree version of any shared file on conflict, re-runs the full suite on :5173, appends the critique to VISUAL-QA.md, then removes the worktrees and servers.

## MCP servers you may have
| Server | Endpoint | Notes |
|---|---|---|
| Derivative TDMCP (official, beta) | `http://127.0.0.1:13316/mcp` | `TDMCP.tox`, 26 tools. |
| Pantani/tdmcp (community) | port **9980** | Collides with the default Web Server DAT port; move one of them. |
| Resolume Wire / Arena MCP | — | Ships with Resolume 7.26+. |
